import Groq from "groq-sdk"

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY })

export async function GET(req) {
  const { searchParams } = new URL(req.url)
  const query = searchParams.get("q") || "handmade jewelry"

  try {
    const completion = await groq.chat.completions.create({
      model: "llama3-8b-8192",
      messages: [
        {
          role: "system",
          content: `You are an Etsy keyword research expert. Return ONLY valid JSON array, no other text.`,
        },
        {
          role: "user",
          content: `Generate 8 related Etsy keyword research results for: "${query}". 
          Return ONLY this JSON format:
          [{"kw":"keyword phrase","volume":50000,"competition":45,"trend":"+32%","avgPrice":"$25","totalListings":12000}]
          Make data realistic for Etsy marketplace. Volume between 1000-300000. Competition 0-100. Include the original query as first result.`,
        },
      ],
      max_tokens: 800,
    })

    const text = completion.choices[0]?.message?.content || "[]"
    const jsonMatch = text.match(/\[[\s\S]*\]/)
    if (!jsonMatch) throw new Error("No JSON found")

    const keywords = JSON.parse(jsonMatch[0])
    return Response.json({ keywords, source: "ai" })
  } catch (err) {
    console.error(err)
    return Response.json({ keywords: getMockKeywords(query), source: "mock" })
  }
}

function getMockKeywords(query) {
  return [
    { kw: query, volume: 124000, competition: 78, trend: "+41%", avgPrice: "$32", totalListings: 45200 },
    { kw: `personalized ${query}`, volume: 89000, competition: 42, trend: "+93%", avgPrice: "$28", totalListings: 23100 },
    { kw: `custom ${query} gift`, volume: 56000, competition: 31, trend: "+37%", avgPrice: "$35", totalListings: 18400 },
    { kw: `handmade ${query}`, volume: 78000, competition: 55, trend: "+29%", avgPrice: "$45", totalListings: 31200 },
    { kw: `${query} for her`, volume: 44000, competition: 28, trend: "+81%", avgPrice: "$38", totalListings: 9800 },
  ]
}
