import Groq from "groq-sdk"

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY })

const systemPrompts = {
  title: "You are an expert Etsy SEO specialist. Generate 5 highly optimized Etsy product titles for the given product. Each title must be under 140 characters, include high-search keywords, and be conversion-focused. Format as a numbered list.",
  description: "You are an expert Etsy copywriter. Write a compelling, SEO-optimized Etsy product description. Include: opening hook, key features as bullet points, materials, use cases, and a call to action.",
  tags: "You are an Etsy SEO expert. Generate exactly 13 Etsy tags for the given product. Tags should be 2-3 words each, highly searched, and relevant. Output as a comma-separated list only.",
}

export async function POST(req) {
  try {
    const { mode, input } = await req.json()

    if (!input || !mode) {
      return Response.json({ error: "Missing input or mode" }, { status: 400 })
    }

    const completion = await groq.chat.completions.create({
      model: "llama3-8b-8192",
      messages: [
        { role: "system", content: systemPrompts[mode] },
        { role: "user", content: input },
      ],
      max_tokens: 1000,
    })

    const text = completion.choices[0]?.message?.content || "No response generated."
    return Response.json({ result: text })
  } catch (err) {
    console.error(err)
    return Response.json({ error: "AI error: " + err.message }, { status: 500 })
  }
}
