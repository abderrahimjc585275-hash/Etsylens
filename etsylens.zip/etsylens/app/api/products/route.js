export async function GET(req) {
  const { searchParams } = new URL(req.url)
  const query = searchParams.get("q") || "handmade jewelry"

  try {
    // Fetch from Etsy search page
    const url = `https://www.etsy.com/search?q=${encodeURIComponent(query)}&ref=search_bar`
    const res = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
      },
    })

    const html = await res.text()

    // Extract JSON data embedded in Etsy's page
    const dataMatch = html.match(/__APOLLO_STATE__\s*=\s*({.+?});\s*<\/script>/s)

    if (!dataMatch) {
      // Return mock data if scraping fails
      return Response.json({ products: getMockProducts(query), source: "mock" })
    }

    const apolloState = JSON.parse(dataMatch[1])
    const products = []

    // Parse listings from Apollo state
    for (const key of Object.keys(apolloState)) {
      const item = apolloState[key]
      if (item.__typename === "Listing" && item.title) {
        products.push({
          id: item.listing_id || key,
          title: item.title,
          price: item.price?.amount ? (item.price.amount / 100).toFixed(2) : "N/A",
          image: item.images?.[0]?.url_570xN || "",
          shop: item.shop?.shop_name || "Unknown Shop",
          favorites: item.num_favorers || 0,
          url: `https://www.etsy.com/listing/${item.listing_id}`,
          competition: getCompetition(item.num_favorers),
          trend: getTrend(),
          sales: estimateSales(item.num_favorers),
          rating: item.rating || 4.8,
          category: query,
        })
      }
      if (products.length >= 12) break
    }

    if (products.length === 0) {
      return Response.json({ products: getMockProducts(query), source: "mock" })
    }

    return Response.json({ products, source: "live" })
  } catch (err) {
    console.error("Scrape error:", err)
    return Response.json({ products: getMockProducts(query), source: "mock" })
  }
}

function getCompetition(favorites) {
  if (favorites > 10000) return "High"
  if (favorites > 3000) return "Medium"
  return "Low"
}

function getTrend() {
  const trends = ["+12%", "+28%", "+45%", "+67%", "+89%", "+33%"]
  return trends[Math.floor(Math.random() * trends.length)]
}

function estimateSales(favorites) {
  return Math.floor((favorites || 100) * 0.3 + Math.random() * 500)
}

function getMockProducts(query) {
  return [
    { id: 1, title: `Personalized ${query} Gift`, price: "28.99", sales: 3420, favorites: 8910, competition: "Low", trend: "+42%", category: query, img: "💎", rating: 4.9, shop: "BloomCraft" },
    { id: 2, title: `Custom ${query} Print`, price: "14.99", sales: 5670, favorites: 21300, competition: "Medium", trend: "+67%", category: query, img: "🎨", rating: 4.8, shop: "ArtStudio" },
    { id: 3, title: `Handmade ${query} Set`, price: "42.00", sales: 1230, favorites: 4200, competition: "High", trend: "+18%", category: query, img: "✨", rating: 4.7, shop: "CraftMade" },
    { id: 4, title: `${query} Template Digital`, price: "8.50", sales: 9820, favorites: 34100, competition: "Low", trend: "+89%", category: query, img: "💌", rating: 5.0, shop: "PaperDreams" },
    { id: 5, title: `Vintage ${query} Pattern`, price: "5.99", sales: 2140, favorites: 7650, competition: "Low", trend: "+55%", category: query, img: "🧶", rating: 4.9, shop: "VintageShop" },
    { id: 6, title: `Modern ${query} Decor`, price: "89.00", sales: 870, favorites: 3200, competition: "Medium", trend: "+31%", category: query, img: "🏠", rating: 4.8, shop: "ModernHome" },
  ]
}
