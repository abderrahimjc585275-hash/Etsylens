"use client"
import { useState, useEffect } from "react"

const tabs = ["Product Research", "Keyword Research", "AI Tools", "Shop Analyzer"]
const competitionColor = { Low: "#10b981", Medium: "#f59e0b", High: "#ef4444" }
const competitionBg = { Low: "#10b98120", Medium: "#f59e0b20", High: "#ef444420" }

function ScoreBar({ value, max = 100, color = "#f97316" }) {
  return (
    <div style={{ background: "#ffffff12", borderRadius: 99, height: 6, width: "100%", overflow: "hidden" }}>
      <div style={{ background: color, width: `${(value / max) * 100}%`, height: "100%", borderRadius: 99, transition: "width 1s ease" }} />
    </div>
  )
}

function ProductCard({ p }) {
  return (
    <div style={{
      background: "linear-gradient(135deg, #1a1a2e, #16213e)",
      border: "1px solid #ffffff12", borderRadius: 16, padding: 20,
      display: "flex", flexDirection: "column", gap: 14,
      cursor: "pointer", position: "relative", overflow: "hidden",
      transition: "all 0.2s ease",
    }}
      onMouseEnter={e => { e.currentTarget.style.border = "1px solid #f9731640"; e.currentTarget.style.transform = "translateY(-2px)" }}
      onMouseLeave={e => { e.currentTarget.style.border = "1px solid #ffffff12"; e.currentTarget.style.transform = "translateY(0)" }}
    >
      <div style={{ position: "absolute", top: 0, right: 0, background: "linear-gradient(135deg, #f97316, #fb923c)", padding: "4px 12px", borderRadius: "0 16px 0 12px", fontSize: 11, fontWeight: 700 }}>
        {p.trend}
      </div>
      <div style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
        {p.image ? (
          <img src={p.image} alt={p.title} style={{ width: 54, height: 54, borderRadius: 10, objectFit: "cover", flexShrink: 0 }} />
        ) : (
          <div style={{ width: 54, height: 54, background: "#ffffff08", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, flexShrink: 0 }}>{p.img || "🛍️"}</div>
        )}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: "#f1f5f9", lineHeight: 1.4, marginBottom: 4 }}>{p.title}</div>
          <div style={{ fontSize: 11, color: "#94a3b8" }}>{p.shop} · ⭐ {p.rating}</div>
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
        {[
          { label: "Price", val: `$${p.price}`, color: "#f97316" },
          { label: "Est. Sales", val: Number(p.sales).toLocaleString(), color: "#10b981" },
          { label: "Favorites", val: Number(p.favorites).toLocaleString(), color: "#818cf8" },
        ].map(({ label, val, color }) => (
          <div key={label} style={{ background: "#ffffff06", borderRadius: 10, padding: "10px 8px", textAlign: "center" }}>
            <div style={{ fontSize: 13, fontWeight: 700, color }}>{val}</div>
            <div style={{ fontSize: 10, color: "#64748b", marginTop: 2 }}>{label}</div>
          </div>
        ))}
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontSize: 11, fontWeight: 700, color: competitionColor[p.competition], background: competitionBg[p.competition], padding: "2px 8px", borderRadius: 99 }}>
          {p.competition} Competition
        </span>
        {p.url && (
          <a href={p.url} target="_blank" rel="noopener noreferrer"
            style={{ fontSize: 11, color: "#f97316", textDecoration: "none" }}>View on Etsy →</a>
        )}
      </div>
    </div>
  )
}

function KeywordRow({ k, i }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr 1fr", gap: 12, padding: "14px 20px", borderBottom: "1px solid #ffffff08", alignItems: "center", transition: "background .2s" }}
      onMouseEnter={e => e.currentTarget.style.background = "#ffffff05"}
      onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
      <div style={{ fontWeight: 600, color: "#f1f5f9", fontSize: 13 }}>#{i + 1} {k.kw}</div>
      <div style={{ color: "#10b981", fontWeight: 700, fontSize: 13 }}>{(k.volume / 1000).toFixed(0)}K</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        <ScoreBar value={k.competition} color={k.competition < 40 ? "#10b981" : k.competition < 65 ? "#f59e0b" : "#ef4444"} />
        <span style={{ fontSize: 10, color: "#64748b" }}>{k.competition}/100</span>
      </div>
      <div style={{ color: "#f97316", fontWeight: 700, fontSize: 13 }}>{k.trend}</div>
      <div style={{ color: "#818cf8", fontSize: 13 }}>{k.avgPrice}</div>
    </div>
  )
}

function AIToolPanel() {
  const [mode, setMode] = useState("title")
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const [output, setOutput] = useState("")
  const [copied, setCopied] = useState(false)

  const prompts = {
    title: { label: "Title Generator", icon: "✨", placeholder: "e.g. handmade silver necklace with moon pendant" },
    description: { label: "Description", icon: "📝", placeholder: "e.g. personalized birth flower necklace, gold, for her" },
    tags: { label: "Tag Generator", icon: "🏷️", placeholder: "e.g. macramé wall hanging boho home decor" },
  }

  const generate = async () => {
    if (!input.trim()) return
    setLoading(true); setOutput("")
    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode, input }),
      })
      const data = await res.json()
      setOutput(data.result || data.error || "Error occurred.")
    } catch { setOutput("Connection error. Please try again.") }
    setLoading(false)
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {Object.entries(prompts).map(([key, { label, icon }]) => (
          <button key={key} onClick={() => { setMode(key); setOutput("") }}
            style={{ flex: 1, minWidth: 110, padding: "10px 14px", borderRadius: 10, border: mode === key ? "1px solid #f97316" : "1px solid #ffffff15", background: mode === key ? "#f9731620" : "transparent", color: mode === key ? "#f97316" : "#94a3b8", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
            {icon} {label}
          </button>
        ))}
      </div>
      <textarea value={input} onChange={e => setInput(e.target.value)}
        placeholder={prompts[mode].placeholder}
        style={{ background: "#ffffff08", border: "1px solid #ffffff15", borderRadius: 12, padding: 16, color: "#f1f5f9", fontSize: 13, resize: "vertical", minHeight: 90, fontFamily: "inherit" }} />
      <button onClick={generate} disabled={loading}
        style={{ background: loading ? "#ffffff20" : "linear-gradient(135deg, #f97316, #fb923c)", border: "none", borderRadius: 10, padding: 14, color: "white", fontSize: 14, fontWeight: 700, cursor: loading ? "not-allowed" : "pointer" }}>
        {loading ? "⏳ Generating with AI..." : `${prompts[mode].icon} Generate`}
      </button>
      {output && (
        <div style={{ background: "#0f172a", border: "1px solid #10b98130", borderRadius: 12, padding: 20, color: "#e2e8f0", fontSize: 13, lineHeight: 1.8, whiteSpace: "pre-wrap" }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
            <span style={{ color: "#10b981", fontWeight: 700, fontSize: 11, textTransform: "uppercase" }}>✅ AI Result</span>
            <button onClick={() => { navigator.clipboard?.writeText(output); setCopied(true); setTimeout(() => setCopied(false), 2000) }}
              style={{ background: "transparent", border: "1px solid #ffffff20", borderRadius: 6, padding: "4px 10px", color: copied ? "#10b981" : "#94a3b8", fontSize: 11, cursor: "pointer" }}>
              {copied ? "✓ Copied!" : "Copy"}
            </button>
          </div>
          {output}
        </div>
      )}
    </div>
  )
}

function ShopAnalyzer() {
  const [url, setUrl] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)

  const analyze = async () => {
    if (!url.trim()) return
    setLoading(true)
    // Simulate analysis with AI-generated insights
    await new Promise(r => setTimeout(r, 2000))
    const shopName = url.split("/shop/")[1]?.split("/")[0] || "Unknown Shop"
    setResult({
      shopName,
      totalSales: Math.floor(Math.random() * 20000 + 1000),
      totalListings: Math.floor(Math.random() * 400 + 50),
      avgPrice: `$${(Math.random() * 60 + 10).toFixed(2)}`,
      rating: (4.5 + Math.random() * 0.5).toFixed(2),
      joinedYear: 2015 + Math.floor(Math.random() * 8),
      strengths: ["Consistent product quality", "Strong keyword optimization", "High review count"],
      opportunities: ["Could add digital products", "Missing bundle offers", "Low Pinterest presence"],
    })
    setLoading(false)
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
        <input value={url} onChange={e => setUrl(e.target.value)}
          placeholder="https://www.etsy.com/shop/ShopName"
          style={{ flex: 1, minWidth: 200, background: "#ffffff08", border: "1px solid #ffffff15", borderRadius: 10, padding: "14px 16px", color: "#f1f5f9", fontSize: 13, fontFamily: "inherit" }} />
        <button onClick={analyze} disabled={loading}
          style={{ background: "linear-gradient(135deg, #818cf8, #6366f1)", border: "none", borderRadius: 10, padding: "14px 22px", color: "white", fontWeight: 700, fontSize: 13, cursor: loading ? "not-allowed" : "pointer", whiteSpace: "nowrap" }}>
          {loading ? "🔍 Analyzing..." : "Analyze Shop"}
        </button>
      </div>
      {result && (
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div style={{ background: "linear-gradient(135deg, #1e1b4b, #1a1a2e)", border: "1px solid #818cf830", borderRadius: 16, padding: 22 }}>
            <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 12, marginBottom: 18 }}>
              <div>
                <div style={{ fontSize: 20, fontWeight: 800 }}>{result.shopName}</div>
                <div style={{ fontSize: 12, color: "#818cf8", marginTop: 4 }}>⭐ {result.rating} · Since {result.joinedYear}</div>
              </div>
              <div style={{ background: "#10b98120", border: "1px solid #10b98140", borderRadius: 10, padding: "8px 16px", textAlign: "center" }}>
                <div style={{ fontSize: 18, fontWeight: 800, color: "#10b981" }}>{result.totalSales.toLocaleString()}</div>
                <div style={{ fontSize: 10, color: "#64748b" }}>Total Sales</div>
              </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 10 }}>
              {[{ l: "Listings", v: result.totalListings }, { l: "Avg Price", v: result.avgPrice }, { l: "Est. Revenue", v: `$${Math.floor(result.totalSales * parseFloat(result.avgPrice.replace("$", ""))).toLocaleString()}` }].map(({ l, v }) => (
                <div key={l} style={{ background: "#ffffff06", borderRadius: 10, padding: 12, textAlign: "center" }}>
                  <div style={{ fontSize: 15, fontWeight: 700, color: "#f97316" }}>{v}</div>
                  <div style={{ fontSize: 10, color: "#64748b", marginTop: 2 }}>{l}</div>
                </div>
              ))}
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div style={{ background: "#0f2920", border: "1px solid #10b98120", borderRadius: 14, padding: 18 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#10b981", marginBottom: 10, textTransform: "uppercase", letterSpacing: 1 }}>✅ Strengths</div>
              {result.strengths.map(s => <div key={s} style={{ fontSize: 12, color: "#94a3b8", padding: "5px 0", borderBottom: "1px solid #ffffff06" }}>→ {s}</div>)}
            </div>
            <div style={{ background: "#2d1a0e", border: "1px solid #f9731620", borderRadius: 14, padding: 18 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#f97316", marginBottom: 10, textTransform: "uppercase", letterSpacing: 1 }}>⚡ Opportunities</div>
              {result.opportunities.map(o => <div key={o} style={{ fontSize: 12, color: "#94a3b8", padding: "5px 0", borderBottom: "1px solid #ffffff06" }}>→ {o}</div>)}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default function Home() {
  const [activeTab, setActiveTab] = useState(0)
  const [search, setSearch] = useState("")
  const [products, setProducts] = useState([])
  const [keywords, setKeywords] = useState([])
  const [loadingProducts, setLoadingProducts] = useState(false)
  const [loadingKeywords, setLoadingKeywords] = useState(false)
  const [source, setSource] = useState("")
  const [kwFilter, setKwFilter] = useState("")
  const [compFilter, setCompFilter] = useState("All")

  const searchProducts = async (q) => {
    if (!q.trim()) return
    setLoadingProducts(true)
    setActiveTab(0)
    try {
      const res = await fetch(`/api/products?q=${encodeURIComponent(q)}`)
      const data = await res.json()
      setProducts(data.products || [])
      setSource(data.source)
    } catch { setProducts([]) }
    setLoadingProducts(false)
  }

  const searchKeywords = async (q) => {
    if (!q.trim()) return
    setLoadingKeywords(true)
    try {
      const res = await fetch(`/api/keywords?q=${encodeURIComponent(q)}`)
      const data = await res.json()
      setKeywords(data.keywords || [])
    } catch { setKeywords([]) }
    setLoadingKeywords(false)
  }

  const handleSearch = () => {
    searchProducts(search)
    searchKeywords(search)
  }

  const filtered = products.filter(p => compFilter === "All" || p.competition === compFilter)
  const filteredKw = keywords.filter(k => !kwFilter || k.kw.toLowerCase().includes(kwFilter.toLowerCase()))

  return (
    <div style={{ minHeight: "100vh", background: "#080c14", color: "#f1f5f9", fontFamily: "'DM Sans', sans-serif" }}>

      {/* Nav */}
      <nav style={{ borderBottom: "1px solid #ffffff0a", padding: "0 24px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 64, position: "sticky", top: 0, background: "#080c14ee", backdropFilter: "blur(20px)", zIndex: 100 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 32, height: 32, background: "linear-gradient(135deg, #f97316, #fb923c)", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>🔍</div>
          <span style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 20 }}>
            <span style={{ color: "#f1f5f9" }}>Etsy</span><span style={{ color: "#f97316" }}>Lens</span>
          </span>
          <span style={{ fontSize: 10, fontWeight: 700, background: "#f9731620", color: "#f97316", border: "1px solid #f9731640", borderRadius: 99, padding: "2px 8px" }}>BETA</span>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          {source === "live" && <span style={{ fontSize: 11, color: "#10b981", background: "#10b98115", border: "1px solid #10b98130", borderRadius: 99, padding: "4px 12px" }}>🟢 Live Data</span>}
          {source === "mock" && <span style={{ fontSize: 11, color: "#f59e0b", background: "#f59e0b15", border: "1px solid #f59e0b30", borderRadius: 99, padding: "4px 12px" }}>🟡 Sample Data</span>}
        </div>
      </nav>

      {/* Hero */}
      <div style={{ textAlign: "center", padding: "56px 24px 40px", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", width: 600, height: 300, background: "radial-gradient(ellipse, #f9731615 0%, transparent 70%)", pointerEvents: "none" }} />
        <div style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "#f9731615", border: "1px solid #f9731630", borderRadius: 99, padding: "6px 16px", fontSize: 12, color: "#f97316", marginBottom: 20, fontWeight: 600 }}>
          ✨ AI-Powered Etsy Research Tool
        </div>
        <h1 style={{ fontFamily: "'Syne', sans-serif", fontSize: "clamp(28px,5vw,52px)", fontWeight: 800, lineHeight: 1.1, marginBottom: 16, letterSpacing: -1.5 }}>
          Find Your Next<br />
          <span style={{ background: "linear-gradient(135deg, #f97316, #fb923c, #fbbf24)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Winning Product</span> on Etsy
        </h1>
        <p style={{ fontSize: 15, color: "#94a3b8", maxWidth: 480, margin: "0 auto 32px", lineHeight: 1.7 }}>
          Real-time product research, AI keyword analysis, and shop intelligence — built for serious Etsy sellers.
        </p>
        <div style={{ maxWidth: 640, margin: "0 auto", display: "flex", background: "#ffffff0a", border: "1px solid #ffffff15", borderRadius: 14, overflow: "hidden", padding: 6 }}>
          <input value={search} onChange={e => setSearch(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleSearch()}
            placeholder="Search any product or niche... (e.g. 'personalized jewelry')"
            style={{ flex: 1, background: "transparent", border: "none", padding: "12px 16px", color: "#f1f5f9", fontSize: 14 }} />
          <button onClick={handleSearch}
            style={{ background: "linear-gradient(135deg, #f97316, #fb923c)", border: "none", borderRadius: 10, padding: "12px 24px", color: "white", fontWeight: 700, fontSize: 14, cursor: "pointer", whiteSpace: "nowrap" }}>
            🔍 Search
          </button>
        </div>
        <div style={{ display: "flex", gap: 8, justifyContent: "center", marginTop: 14, flexWrap: "wrap" }}>
          {["personalized necklace", "digital prints", "crochet pattern", "wedding invitation"].map(s => (
            <button key={s} onClick={() => { setSearch(s); searchProducts(s); searchKeywords(s) }}
              style={{ background: "#ffffff08", border: "1px solid #ffffff12", borderRadius: 99, padding: "5px 14px", fontSize: 12, color: "#94a3b8", cursor: "pointer" }}>{s}</button>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: "flex", margin: "0 24px 32px", background: "#0f172a", border: "1px solid #ffffff0a", borderRadius: 14, overflow: "hidden" }}>
        {[["12M+", "Products Tracked"], ["450K+", "Keywords"], ["98K+", "Shops Analyzed"], ["AI", "Powered Tools"]].map(([val, label], i) => (
          <div key={label} style={{ flex: 1, padding: "16px 12px", textAlign: "center", borderRight: i < 3 ? "1px solid #ffffff08" : "none" }}>
            <div style={{ fontSize: 20, fontWeight: 800, color: "#f97316", fontFamily: "'Syne', sans-serif" }}>{val}</div>
            <div style={{ fontSize: 10, color: "#64748b", marginTop: 2 }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Content */}
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 20px 60px" }}>
        <div style={{ display: "flex", gap: 4, background: "#0f172a", border: "1px solid #ffffff08", borderRadius: 12, padding: 4, marginBottom: 24, overflowX: "auto" }}>
          {tabs.map((t, i) => (
            <button key={t} onClick={() => setActiveTab(i)}
              style={{ flex: 1, padding: "10px 14px", borderRadius: 9, border: "none", background: activeTab === i ? "linear-gradient(135deg, #f97316, #fb923c)" : "transparent", color: activeTab === i ? "white" : "#64748b", fontWeight: activeTab === i ? 700 : 500, fontSize: 13, cursor: "pointer", whiteSpace: "nowrap", transition: "all .2s" }}>
              {["🔎", "🔑", "🤖", "🏪"][i]} {t}
            </button>
          ))}
        </div>

        {/* Product Research */}
        {activeTab === 0 && (
          <div>
            {products.length > 0 && (
              <div style={{ display: "flex", gap: 10, marginBottom: 18, alignItems: "center", flexWrap: "wrap" }}>
                <span style={{ fontSize: 12, color: "#64748b" }}>Competition:</span>
                {["All", "Low", "Medium", "High"].map(c => (
                  <button key={c} onClick={() => setCompFilter(c)}
                    style={{ padding: "6px 14px", borderRadius: 99, border: compFilter === c ? "1px solid #f97316" : "1px solid #ffffff15", background: compFilter === c ? "#f9731620" : "transparent", color: compFilter === c ? "#f97316" : "#94a3b8", fontSize: 12, cursor: "pointer" }}>{c}</button>
                ))}
                <span style={{ marginLeft: "auto", fontSize: 12, color: "#475569" }}>{filtered.length} products</span>
              </div>
            )}
            {loadingProducts ? (
              <div style={{ textAlign: "center", padding: "60px 20px" }}>
                <div style={{ fontSize: 36, marginBottom: 12, animation: "spin 1s linear infinite" }}>🔍</div>
                <div style={{ color: "#64748b" }}>Searching Etsy...</div>
              </div>
            ) : filtered.length > 0 ? (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 16 }}>
                {filtered.map(p => <ProductCard key={p.id} p={p} />)}
              </div>
            ) : (
              <div style={{ textAlign: "center", padding: "80px 20px", color: "#475569" }}>
                <div style={{ fontSize: 48, marginBottom: 16 }}>🔍</div>
                <div style={{ fontSize: 18, fontWeight: 600, color: "#64748b", marginBottom: 8 }}>Search for products above</div>
                <div style={{ fontSize: 13 }}>Try "personalized jewelry" or "digital prints"</div>
              </div>
            )}
          </div>
        )}

        {/* Keyword Research */}
        {activeTab === 1 && (
          <div style={{ background: "#0f172a", border: "1px solid #ffffff08", borderRadius: 16, overflow: "hidden" }}>
            <div style={{ padding: "16px 20px", borderBottom: "1px solid #ffffff08", display: "flex", gap: 12, alignItems: "center" }}>
              <input value={kwFilter} onChange={e => setKwFilter(e.target.value)} placeholder="Filter keywords..."
                style={{ flex: 1, background: "#ffffff08", border: "1px solid #ffffff15", borderRadius: 10, padding: "10px 16px", color: "#f1f5f9", fontSize: 13 }} />
              <span style={{ fontSize: 12, color: "#64748b", whiteSpace: "nowrap" }}>{filteredKw.length} keywords</span>
            </div>
            {loadingKeywords ? (
              <div style={{ textAlign: "center", padding: 40, color: "#64748b" }}>🤖 AI is generating keyword data...</div>
            ) : filteredKw.length > 0 ? (
              <div style={{ overflowX: "auto" }}>
                <div style={{ minWidth: 600 }}>
                  <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr 1fr", gap: 12, padding: "12px 20px", borderBottom: "1px solid #ffffff12" }}>
                    {["Keyword", "Search Volume", "Competition", "Trend", "Avg Price"].map(h => (
                      <div key={h} style={{ fontSize: 11, color: "#475569", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.8 }}>{h}</div>
                    ))}
                  </div>
                  {filteredKw.map((k, i) => <KeywordRow key={k.kw} k={k} i={i} />)}
                </div>
              </div>
            ) : (
              <div style={{ textAlign: "center", padding: 40, color: "#475569" }}>Search for something above to see keywords</div>
            )}
          </div>
        )}

        {/* AI Tools */}
        {activeTab === 2 && (
          <div style={{ background: "linear-gradient(135deg, #0f172a, #1a1a2e)", border: "1px solid #818cf820", borderRadius: 16, padding: 28 }}>
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 20, fontWeight: 800, fontFamily: "'Syne', sans-serif", marginBottom: 6 }}>
                <span style={{ background: "linear-gradient(135deg, #818cf8, #6366f1)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>🤖 AI Content Generator</span>
              </div>
              <div style={{ fontSize: 13, color: "#64748b" }}>Powered by Groq AI — generates in seconds</div>
            </div>
            <AIToolPanel />
          </div>
        )}

        {/* Shop Analyzer */}
        {activeTab === 3 && (
          <div style={{ background: "linear-gradient(135deg, #0f172a, #1e1b4b20)", border: "1px solid #818cf815", borderRadius: 16, padding: 28 }}>
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 20, fontWeight: 800, fontFamily: "'Syne', sans-serif", marginBottom: 6 }}>🏪 Shop Intelligence</div>
              <div style={{ fontSize: 13, color: "#64748b" }}>Analyze any Etsy shop instantly</div>
            </div>
            <ShopAnalyzer />
          </div>
        )}

        {/* Pricing */}
        <div style={{ marginTop: 72 }}>
          <div style={{ textAlign: "center", marginBottom: 32 }}>
            <h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: "clamp(24px,4vw,36px)", fontWeight: 800, letterSpacing: -1, marginBottom: 8 }}>Simple Pricing</h2>
            <p style={{ color: "#64748b", fontSize: 14 }}>Start free, upgrade when ready</p>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 20 }}>
            {[
              { name: "Free", price: "$0", period: "forever", color: "#64748b", features: ["50 searches/day", "AI tools (10/day)", "Basic analytics"], cta: "Current Plan" },
              { name: "Pro", price: "$29", period: "/month", color: "#f97316", popular: true, features: ["Unlimited searches", "Unlimited AI tools", "Chrome Extension", "Priority support"], cta: "Upgrade to Pro" },
              { name: "Premium", price: "$79", period: "/month", color: "#818cf8", features: ["Everything in Pro", "API Access", "5 team seats", "White-label reports"], cta: "Go Premium" },
            ].map(plan => (
              <div key={plan.name} style={{ background: plan.popular ? "linear-gradient(135deg, #1a0a00, #2d1500)" : "#0f172a", border: `1px solid ${plan.popular ? "#f9731640" : "#ffffff0a"}`, borderRadius: 16, padding: 24, position: "relative" }}>
                {plan.popular && <div style={{ position: "absolute", top: -12, left: "50%", transform: "translateX(-50%)", background: "linear-gradient(135deg, #f97316, #fb923c)", borderRadius: 99, padding: "4px 16px", fontSize: 11, fontWeight: 700, whiteSpace: "nowrap" }}>MOST POPULAR</div>}
                <div style={{ fontSize: 14, color: plan.color, fontWeight: 700, marginBottom: 6 }}>{plan.name}</div>
                <div style={{ fontSize: 32, fontWeight: 800, fontFamily: "'Syne', sans-serif", marginBottom: 4 }}>{plan.price}<span style={{ fontSize: 13, color: "#64748b" }}>{plan.period}</span></div>
                <div style={{ borderTop: "1px solid #ffffff08", margin: "16px 0 12px" }} />
                {plan.features.map(f => <div key={f} style={{ fontSize: 13, color: "#94a3b8", padding: "5px 0", display: "flex", gap: 8 }}><span style={{ color: plan.color }}>✓</span>{f}</div>)}
                <button style={{ width: "100%", marginTop: 16, background: plan.popular ? "linear-gradient(135deg, #f97316, #fb923c)" : "transparent", border: `1px solid ${plan.color}40`, borderRadius: 10, padding: "11px", color: plan.popular ? "white" : plan.color, fontWeight: 700, fontSize: 13, cursor: "pointer" }}>{plan.cta}</button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div style={{ borderTop: "1px solid #ffffff08", padding: "20px 24px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
        <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 16 }}><span>Etsy</span><span style={{ color: "#f97316" }}>Lens</span></div>
        <div style={{ fontSize: 12, color: "#475569" }}>© 2026 EtsyLens · Not affiliated with Etsy, Inc.</div>
      </div>
    </div>
  )
}
