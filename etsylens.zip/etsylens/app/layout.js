import "./globals.css"

export const metadata = {
  title: "EtsyLens — Find Winning Etsy Products",
  description: "AI-powered product research, keyword analysis, and shop intelligence for Etsy sellers.",
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Syne:wght@700;800&display=swap" rel="stylesheet" />
      </head>
      <body>{children}</body>
    </html>
  )
}
